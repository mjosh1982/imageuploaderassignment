create function st_polyfromtext(text)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'POLYGON'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END

$$;

alter function st_polyfromtext(text)
  owner to manojjoshi;

