create function st_covers(geography, geography)
  returns boolean
immutable
parallel safe
language sql
as $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Covers($1, $2)
$$;

comment on function st_covers(geography, geography)
is 'args: geogpolyA, geogpointB - Returns 1 (TRUE) if no point in Geometry B is outside Geometry A';

alter function st_covers(geography, geography)
  owner to manojjoshi;

