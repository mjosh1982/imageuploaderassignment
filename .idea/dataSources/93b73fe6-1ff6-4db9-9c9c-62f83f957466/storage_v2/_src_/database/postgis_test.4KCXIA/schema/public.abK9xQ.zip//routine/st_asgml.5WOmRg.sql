create function st_asgml(geog geography, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0)
  returns text
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_AsGML(2, $1, $2, $3, null, null)
$$;

comment on function st_asgml(geography, integer, integer)
is 'args: geog, maxdecimaldigits=15, options=0 - Return the geometry as a GML version 2 or 3 element.';

alter function st_asgml(geography, integer, integer)
  owner to manojjoshi;

