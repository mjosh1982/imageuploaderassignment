create function st_approxquantile(rastertable text, rastercolumn text, nband integer, sample_percent double precision, quantile double precision)
  returns double precision
stable
strict
language sql
as $$
SELECT ( public._ST_quantile($1, $2, $3, TRUE, $4, ARRAY[$5]::double precision[])).value
$$;

alter function st_approxquantile(text, text, integer, double precision, double precision)
  owner to manojjoshi;

